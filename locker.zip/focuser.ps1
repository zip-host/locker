#requires -Version 2
Add-Type @"
  using System;
  using System.Runtime.InteropServices;
  public class Tricks {
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
}
"@

function Show-Process($Process, [Switch]$Maximize)
{
  $sig = '
    [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);
  '
  if ($Maximize) { $Mode = 3 } else { $Mode = 4 }
  $type = Add-Type -MemberDefinition $sig -Name WindowAPI -PassThru
  $hwnd = $process.MainWindowHandle
  $null = $type::ShowWindowAsync($hwnd, 3)
  $null = $type::SetForegroundWindow($hwnd) 
}


$proc="python"
$adm = ""

while(1){

#$p = Get-Process | Where {$_.mainWindowTitle} | Where {$_.Name -like "$proc"}
$p = Get-Process | Where {$_.Name -like "$proc"}
write-host $p
if (($p -eq $null) -and ($adm -ne "")) {
    #Start-Process "$proc" -Verb runAs
} elseif (($p -eq $null) -and ($adm -eq "")) {
    #Start-Process "$proc"
} else {
    #Show-Process -Process $p -Maximize
    $a = [tricks]::GetForegroundWindow()
    $ative = get-process | ? { $_.mainwindowhandle -eq $a }
    if($ative.Name.Contains('python')){

    }else {
        stop-process -id $ative.Id
    }

    write-host $ative;
    foreach($procs in $p){
        Show-Process -Process $procs -Maximize
    }
   
}

if(Test-Path -Path "C:\ProgramData\policee\off.txt"){
  Exit;
}
start-sleep -s 1
}